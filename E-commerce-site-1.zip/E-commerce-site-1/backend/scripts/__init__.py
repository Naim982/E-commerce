"""Scripts package initialization."""
