"""LUMEN Hardware — FastAPI Backend Package."""
__version__ = "1.0.0"
